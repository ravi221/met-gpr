import {Component} from '@angular/core';

/**
 * Stub of the {@link MainNavMenuComponent}
 */
@Component({selector: 'gpr-main-nav-menu', template: ``})
export class MainMenuNavStubComponent {
}
