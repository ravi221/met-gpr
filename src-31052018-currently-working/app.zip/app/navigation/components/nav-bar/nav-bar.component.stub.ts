import {Component} from '@angular/core';

/**
 * Stub of {@link NavBarComponent}
 */
@Component({selector: 'gpr-nav-bar', template: ``})
export class NavBarStubComponent {
}
