import {Component} from '@angular/core';

/**
 * Stub of {@link BreadcrumbsComponent}
 */
@Component({selector: 'gpr-breadcrumbs', template: ` `})
export class BreadcrumbsStubComponent {
}
