/**
 * An enumeration to represent the ways to view a comment
 */
export enum CommentViewTypes {
  COMPACT = 'Compact',
  DEFAULT = 'Default'
}
