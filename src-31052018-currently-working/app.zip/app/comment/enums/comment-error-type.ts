/**
 * An enumeration to represent the error type  */
export enum CommentErrorType {
    CREATE_ERROR = 'Create Error',
    NULL_ERROR = 'Null Error'
}
