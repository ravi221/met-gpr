import { Component, Input } from '@angular/core';

@Component({
    selector: 'gpr-flag-landing',
    template: ``
  })
  export class FlagLandingStubComponent {
  }
