/**
 * An enumeration to represent the context of where the flags icon is clicked  */
export enum FlagsContextTypes {
    CUSTOMER_HOME_PAGE = 'Customer Home Page',
    PLAN_HOME_PAGE = 'Plan Home Page'
}
