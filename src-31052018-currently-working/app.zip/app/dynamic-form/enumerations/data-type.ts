/**
 * Possible data types for values in gpr
 */
export enum DataType {
  DECIMAL = 'decimal',
  NUMBER = 'number',
  STRING = 'string'
}
