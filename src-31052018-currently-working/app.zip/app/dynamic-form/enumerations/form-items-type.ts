/**
 * An enumeration of the possible items you can put on a form
 */
export enum FormItemType {
  GROUPED_QUESTION = 'grouped question',
  SINGLE_QUESTION= 'single question'
}
