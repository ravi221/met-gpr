/**
 * Action Style for category
 */
export enum CategoryActionStyle {
  TERTIARY = 'tertiary',
  SECONDARY = 'secondary'
}

