/**
 * Icon State for category
 */
export enum CategoryIconState {
    ON = 'on',
    OFF = 'off',
    EMPTY = ''
}
