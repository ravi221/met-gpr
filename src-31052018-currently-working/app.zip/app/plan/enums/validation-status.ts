/**
 * Validation Status for Plans, Categories, and Sections
 */
export enum ValidationStatus {
    VALIDATED = 'Validated',
    NOT_VALIDATED = 'Not Validated'
}
