/**
 * Action label for category
 */
export enum CategoryActionLabel {
    START = 'START',
    RESUME = 'RESUME',
    EDIT = 'EDIT',
    VALIDATE = 'VALIDATE',
    VIEW = 'VIEW'
}

