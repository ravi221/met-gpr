/**
 * Indicates the Section Validation Status
 */
export enum SectionValidationStatus {
    VALIDATED = 'Y',
    NOT_VALIDATED = 'N'
}
