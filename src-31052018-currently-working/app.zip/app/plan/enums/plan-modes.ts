/**
 * Modes used by plan input grid to determine how the UI will differ between creat and copy plan
 */
export enum PlanModes {
  CREATE = 'create',
  COPY = 'copy'
}
