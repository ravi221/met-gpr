/**
 * Indicates Completion Percentage of Categories
 */
export enum CompletionPercentage {
    COMPLETE = 100
}
