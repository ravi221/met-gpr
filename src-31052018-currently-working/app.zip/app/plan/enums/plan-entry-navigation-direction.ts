/**
 * Navigation directions for plan entry screens
 */
export enum PlanEntryNavigationDirection {
    NEXT = 'next',
    PREVIOUS = 'previous'
}
