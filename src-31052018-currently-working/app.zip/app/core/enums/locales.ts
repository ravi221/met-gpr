/**
 * Contains a list of locales
 */
export enum Locales {
  US = 'en-US'
}
