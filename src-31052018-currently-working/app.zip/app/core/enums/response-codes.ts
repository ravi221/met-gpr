/**
 * Response codes from service calls
 */
export enum ResponseCodes {
    SUCCESS = 'SUCCESS'
}
