/**
 * Constant used for any request error
 * @type {string}
 */
export const REQUEST_ERROR = 'An error occurred while processing your request';
